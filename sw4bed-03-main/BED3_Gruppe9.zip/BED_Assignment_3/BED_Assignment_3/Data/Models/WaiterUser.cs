﻿using System.ComponentModel.DataAnnotations;
using Microsoft.EntityFrameworkCore.Metadata.Internal;
using System.ComponentModel.DataAnnotations.Schema;
using Microsoft.AspNetCore.Identity;

namespace BED_Assignment_3.Data.Models
{
    public class WaiterUser : IdentityUser
    {
    }
}

﻿namespace BED_Assignment_3.Hub
{
	public interface IKitchenHub
	{
		Task KitchenUpdate();
	}
}
